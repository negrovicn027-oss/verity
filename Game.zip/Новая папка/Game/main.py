import pygame
import random
import math
import array
import sys
import ctypes
import os

# --- УНИВЕРСАЛЬНЫЙ ПУТЬ К РЕСУРСАМ ---
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# Фикс для звука в exe
os.environ['SDL_AUDIODRIVER'] = 'directsound'

pygame.init()
pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)

# --- НАСТРОЙКИ ---
WIDTH, HEIGHT = 500, 500
back = (20, 20, 30)
is_fullscreen = False
mw = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Verity: Glitch in System')
clock = pygame.time.Clock()

# --- ЛОКАЛИЗАЦИЯ (ЯЗЫКИ) ---
current_lang = 'ru'

TEXTS = {
    'ru': {
        'title': 'ВЕРИТИ', 'subtitle': 'ПРЫГАЕТ НА КРОВАТИ', 'goal': 'ЦЕЛЬ: УБРАТЬ ДМИТРИЯ НАГИЕВА',
        'record': 'Рекорд: {}', 'diff': 'Сложность:', 'slow': 'Медленно', 'medium': 'Средне', 'fast': 'Быстро',
        'play': 'ИГРАТЬ', 'mp': 'МУЛЬТИПЛЕЕР', 'shop': 'МАГАЗИН', 'settings': 'НАСТРОЙКИ', 'help': 'КАК ИГРАТЬ',
        'music_on': 'Музыка: ВКЛ', 'music_off': 'Музыка: ВЫКЛ', 'next_track': 'Следующий трек',
        'vol': 'Громкость: {}%', 'vol_hint': 'Регулируй клавишами + и -',
        'fs_on': 'Полноэкранный: ВКЛ', 'fs_off': 'Полноэкранный: ВЫКЛ', 'back': 'НАЗАД',
        'points': 'Очки: {}', 'shop_close': 'B или Esc - Закрыть',
        'item_life': 'Доп. жизнь', 'item_width': 'Широкая кровать', 'item_slow': 'Сброс скорости', 'item_speed': 'Ускорение кровати',
        'admin_panel': 'АДМИН ПАНЕЛЬ', 'admin_score': '+ 1000 Очков', 'admin_lives': '+ 5 Жизней',
        'admin_kill': 'Убить всех Нагиевых', 'admin_god_on': 'Бессмертие: ВКЛ', 'admin_god_off': 'Бессмертие: ВЫКЛ',
        'close': 'ЗАКРЫТЬ', 'admin_hint': 'TAB или Esc - Закрыть',
        'score': 'Убрано: {}', 'level': 'Уровень: {}', 'secret': 'СЕКРЕТ', 'lives': 'Жизни: {}',
        'paused': 'ПАУЗА', 'pause_esc': 'Esc - Продолжить', 'pause_m': 'M - В меню',
        'lose': 'НАГИЕВ ПОБЕДИЛ...', 'win': 'ПОЛНАЯ ПОБЕДА!', 'win_sub': 'НАГИЕВ УБРАН!',
        'total': 'Убрано Нагиевых: {}', 'new_rec': 'НОВЫЙ РЕКОРД!', 'restart': 'R - Играть снова', 'menu': 'M - В меню',
        'glitch_win': 'ГЛИТЧ ПОБЕДА', 'reality': 'РЕАЛЬНОСТЬ СЛОМАНА', 'your_score': 'Твой счет: {}',
        'p1_win': 'ИГРОК 1 ПОБЕДИЛ!', 'p2_win': 'ИГРОК 2 ПОБЕДИЛ!', 'mp_esc': 'Esc - В меню',
        'help_text': [
            "Сюжет: Верити выбивает Нагиева.", "Управление: <- и ->",
            "МУЛЬТИПЛЕЕР: P1 (W/S), P2 (Стрелки)", "Первый до 5 очков побеждает!",
            "Секретный куб: ловите его кроватью!", "TAB - Админка (Читы)",
            "F11 - Полный экран", "Esc - Пауза"
        ]
    },
    'en': {
        'title': 'VERITY', 'subtitle': 'JUMPS ON THE BED', 'goal': 'GOAL: REMOVE DMITRY NAGIEV',
        'record': 'Record: {}', 'diff': 'Difficulty:', 'slow': 'Slow', 'medium': 'Medium', 'fast': 'Fast',
        'play': 'PLAY', 'mp': 'MULTIPLAYER', 'shop': 'SHOP', 'settings': 'SETTINGS', 'help': 'HOW TO PLAY',
        'music_on': 'Music: ON', 'music_off': 'Music: OFF', 'next_track': 'Next track',
        'vol': 'Volume: {}%', 'vol_hint': 'Adjust with + and -',
        'fs_on': 'Fullscreen: ON', 'fs_off': 'Fullscreen: OFF', 'back': 'BACK',
        'points': 'Points: {}', 'shop_close': 'B or Esc - Close',
        'item_life': 'Extra Life', 'item_width': 'Wide Bed', 'item_slow': 'Slow Down', 'item_speed': 'Bed Speed Up',
        'admin_panel': 'ADMIN PANEL', 'admin_score': '+ 1000 Score', 'admin_lives': '+ 5 Lives',
        'admin_kill': 'Kill All Nagievs', 'admin_god_on': 'God Mode: ON', 'admin_god_off': 'God Mode: OFF',
        'close': 'CLOSE', 'admin_hint': 'TAB or Esc - Close',
        'score': 'Removed: {}', 'level': 'Level: {}', 'secret': 'SECRET', 'lives': 'Lives: {}',
        'paused': 'PAUSED', 'pause_esc': 'Esc - Resume', 'pause_m': 'M - Menu',
        'lose': 'NAGIEV WON...', 'win': 'TOTAL VICTORY!', 'win_sub': 'NAGIEV IS GONE!',
        'total': 'Nagievs removed: {}', 'new_rec': 'NEW RECORD!', 'restart': 'R - Play again', 'menu': 'M - Menu',
        'glitch_win': 'GLITCH VICTORY', 'reality': 'REALITY BROKEN', 'your_score': 'Your score: {}',
        'p1_win': 'PLAYER 1 WON!', 'p2_win': 'PLAYER 2 WON!', 'mp_esc': 'Esc - Menu',
        'help_text': [
            "Story: Verity smashes Nagiev.", "Controls: <- and ->",
            "MULTIPLAYER: P1 (W/S), P2 (Arrows)", "First to 5 points wins!",
            "Secret cube: catch it with the bed!", "TAB - Admin Panel (Cheats)",
            "F11 - Fullscreen", "Esc - Pause"
        ]
    }
}

def T(key, *args):
    text = TEXTS[current_lang][key]
    if args:
        return text.format(*args)
    return text

# --- ИКОНКА ---
try:
    icon_path = resource_path('icon.png')
    if os.path.exists(icon_path):
        icon = pygame.image.load(icon_path)
        pygame.display.set_icon(icon)
    myappid = 'mycompany.veritygame.1.0'
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
except: pass

# --- ПЛЕЙЛИСТ ---
ALL_TRACKS = ['verity_theme.mp3', 'track2.mp3', 'track3.mp3'] 
PLAYLIST = [track for track in ALL_TRACKS if os.path.exists(resource_path(track))]
music_on = len(PLAYLIST) > 0
current_track_idx = 0
music_volume = 0.5
MUSIC_END = pygame.USEREVENT + 1
pygame.mixer.music.set_endevent(MUSIC_END)

def play_track(idx):
    global current_track_idx, music_on
    if not PLAYLIST: return
    current_track_idx = idx % len(PLAYLIST)
    try:
        pygame.mixer.music.load(resource_path(PLAYLIST[current_track_idx]))
        pygame.mixer.music.set_volume(music_volume)
        pygame.mixer.music.play()
        music_on = True
    except: music_on = False

play_track(0)

# --- ГЕНЕРАТОР ЗВУКОВ ---
def make_sound(freq, duration, volume=0.3, wave_type='sine'):
    sample_rate = 22050
    n_samples = int(sample_rate * duration)
    buf = array.array('h', [0] * n_samples)
    for i in range(n_samples):
        t = float(i) / sample_rate
        val = math.sin(2 * math.pi * freq * t) if wave_type == 'sine' else (1.0 if math.sin(2 * math.pi * freq * t) > 0 else -1.0)
        buf[i] = int(volume * 32767 * val * (1.0 - (i / n_samples)))
    return pygame.mixer.Sound(buffer=buf)

snd_bounce = make_sound(400, 0.1, 0.2, 'square')
snd_break = make_sound(800, 0.15, 0.2, 'square')
snd_power = make_sound(1200, 0.2, 0.3, 'sine')
snd_lose = make_sound(150, 0.5, 0.4, 'square')
snd_win = make_sound(600, 0.4, 0.3, 'sine')
snd_glitch = make_sound(100, 0.8, 0.5, 'square')

try: 
    snd_game_over = pygame.mixer.Sound(resource_path('game_over.mp3')); snd_game_over.set_volume(0.8)
except: snd_game_over = snd_lose
try: 
    snd_victory = pygame.mixer.Sound(resource_path('victory.ogg')); snd_victory.set_volume(0.8)
except: snd_victory = snd_win

# --- КЛАССЫ ---
class Area():
    def __init__(self, x, y, w, h, color=None):
        self.rect = pygame.Rect(x, y, w, h)
        self.fill_color = color if color else back

class Picture(Area):
    def __init__(self, filename, x=0, y=0, w=10, h=10):
        super().__init__(x, y, w, h)
        try:
            self.image = pygame.image.load(resource_path(filename)).convert_alpha()
            self.image = pygame.transform.scale(self.image, (w, h))
        except:
            self.image = pygame.Surface((w, h))
            self.image.fill((255, 255, 0))

    def draw(self, surface):
        surface.blit(self.image, (self.rect.x, self.rect.y))

class GlitchCube(Area):
    def __init__(self, x, y):
        super().__init__(x, y, 30, 30)
        self.timer = 0

    def update(self):
        self.rect.y += 4
        self.timer += 1

    def draw(self, surface):
        colors = [(255, 0, 255), (0, 255, 255), (255, 255, 0), (0, 255, 0)]
        color = colors[(self.timer // 5) % len(colors)]
        offset_x = random.randint(-2, 2)
        offset_y = random.randint(-2, 2)
        pygame.draw.rect(surface, color, (self.rect.x + offset_x, self.rect.y + offset_y, 30, 30))
        pygame.draw.rect(surface, (255, 255, 255), (self.rect.x, self.rect.y, 30, 30), 2)

class Button(Area):
    def __init__(self, x, y, w, h, text, size=24, bg=(200, 200, 200), fg=(0, 0, 0)):
        super().__init__(x, y, w, h, bg)
        self.text_img = pygame.font.SysFont('verdana', size, bold=True).render(text, True, fg)
        self.bg = bg
        self.size = size
        self.fg = fg

    def draw(self, surface, hover=False):
        color = (255, 255, 100) if hover else self.bg
        pygame.draw.rect(surface, color, self.rect, border_radius=8)
        pygame.draw.rect(surface, (255, 255, 255), self.rect, 2, border_radius=8)
        tr = self.text_img.get_rect(center=self.rect.center)
        surface.blit(self.text_img, tr)

    def update_text(self, text):
        self.text_img = pygame.font.SysFont('verdana', self.size, bold=True).render(text, True, self.fg)

class Particle():
    def __init__(self, x, y, color, is_smile=False):
        self.x, self.y = x, y
        self.vx = random.uniform(-5, 5)
        self.vy = random.uniform(-5, 5)
        self.life = 30
        self.color = color
        self.is_smile = is_smile

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.2
        self.life -= 1

    def draw(self, surface):
        if self.life > 0:
            if self.is_smile and self.life > 10:
                pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), 6)
                pygame.draw.circle(surface, (0,0,0), (int(self.x)-2, int(self.y)-2), 1)
                pygame.draw.circle(surface, (0,0,0), (int(self.x)+2, int(self.y)-2), 1)
                pygame.draw.arc(surface, (0,0,0), (int(self.x)-4, int(self.y)-2, 8, 6), math.pi, 2*math.pi, 1)
            else:
                pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), max(1, self.life // 5))

class PowerUp(Picture):
    def __init__(self, x, y, p_type):
        self.p_type = p_type 
        color = (0, 255, 0) if p_type == 'expand' else (0, 150, 255)
        super().__init__('', x, y, 20, 20)
        self.image.fill(color)
        pygame.draw.circle(self.image, (255, 255, 255), (10, 10), 5)

    def update(self):
        self.rect.y += 3

# --- ИНИЦИАЛИЗАЦИЯ ---
def draw_text(surface, text, size, color, cx, cy, shadow=True):
    font = pygame.font.SysFont('verdana', size, bold=True)
    if shadow:
        s_img = font.render(text, True, (0,0,0))
        surface.blit(s_img, s_img.get_rect(center=(cx+2, cy+2)))
    img = font.render(text, True, color)
    surface.blit(img, img.get_rect(center=(cx, cy)))

speed_settings = {'slow': 3, 'medium': 5, 'fast': 7}
current_speed_key = 'medium'

score = 0; high_score = 0; lives = 3; level = 1
nagievs, powerups, particles = [], [], []
glitch_cube = None; platform_speed = 6
game_state = 'menu'; prev_state = 'menu'
game_result = ''; is_secret_level = False; god_mode = False 
expand_timer = 0; slow_timer = 0
base_dx, base_dy = 0, 0
verity, bed = None, None    
dx, dy = 0, 0
shake_timer, shake_intensity = 0, 0
verity_trail = []

mp_p1_score = 0; mp_p2_score = 0; mp_dx, mp_dy = 6, 6
p1_paddle, p2_paddle, mp_ball = None, None, None
bed_img_rotated = None

shop_items = [
    {"key": "item_life", "cost": 100, "action": "life", "rect": pygame.Rect(100, 150, 300, 40)},
    {"key": "item_width", "cost": 50, "action": "width", "rect": pygame.Rect(100, 200, 300, 40)},
    {"key": "item_slow", "cost": 30, "action": "slow", "rect": pygame.Rect(100, 250, 300, 40)},
    {"key": "item_speed", "cost": 80, "action": "speed", "rect": pygame.Rect(100, 300, 300, 40)}
]

back_shop_btn = Button(150, 400, 200, 40, T('back'), 18, (150, 150, 150))
fs_btn = Button(150, 250, 200, 50, T('fs_off'), 18, (100, 255, 100))
back_settings_btn = Button(150, 380, 200, 50, T('back'), 20, (200, 200, 200))
back_help_btn = Button(150, 440, 200, 40, T('back'), 16, (150, 150, 150))

admin_btn_add_score = Button(100, 100, 300, 40, T('admin_score'), 18, (100, 200, 255))
admin_btn_add_lives = Button(100, 160, 300, 40, T('admin_lives'), 18, (100, 255, 100))
admin_btn_kill_all = Button(100, 220, 300, 40, T('admin_kill'), 18, (255, 100, 100))
admin_btn_god = Button(100, 280, 300, 40, T('admin_god_off'), 18, (200, 200, 200))
admin_btn_exit = Button(150, 400, 200, 40, T('close'), 18, (255, 255, 100))

def create_level():
    global nagievs, verity, bed, dx, dy, base_dx, base_dy, expand_timer, slow_timer, verity_trail, is_secret_level, back
    nagievs.clear(); powerups.clear(); particles.clear(); verity_trail.clear()
    expand_timer = 0; slow_timer = 0
    back = (40, 0, 40) if is_secret_level else (20, 20, 30)

    if not bed:
        bed = Picture('bed.png', WIDTH//2 - 50, HEIGHT - 70, 100, 30)
    else:
        bed.rect.centerx = WIDTH // 2; bed.rect.bottom = HEIGHT - 20
        bed.image = pygame.transform.scale(pygame.image.load(resource_path('bed.png')).convert_alpha(), (100, 30))
        bed.rect.width = 100

    if not verity:
        verity = Picture('verity.png', WIDTH//2 - 15, HEIGHT//2, 30, 30)
    else:
        verity.rect.center = (WIDTH // 2, HEIGHT // 2)

    base_dx = 3 if is_secret_level else (speed_settings[current_speed_key] + (level - 1) * 0.4)
    base_dy = -base_dx
    dx, dy = base_dx, base_dy

    rows = 4 if not is_secret_level else 5
    count = 9 if not is_secret_level else 10 
    spacing = 55 if not is_secret_level else 45 
    
    for j in range(rows):
        y = 60 + (45 * j)
        x = WIDTH//2 - (count * spacing)//2 
        for i in range(count):
            nagievs.append(Picture('egg.png', x, y, 45, 45))
            x += spacing
        count -= 1

def reset_game():
    global score, lives, level, platform_speed, is_secret_level, game_result, god_mode
    score = 0; lives = 3; level = 1; platform_speed = 6
    is_secret_level = False; game_result = ''; god_mode = False
    create_level()

def init_multiplayer():
    global mp_p1_score, mp_p2_score, mp_dx, mp_dy, p1_paddle, p2_paddle, mp_ball, bed_img_rotated
    mp_p1_score = 0; mp_p2_score = 0; mp_dx = 6; mp_dy = 6
    bed_img = pygame.image.load(resource_path('bed.png')).convert_alpha()
    bed_img_scaled = pygame.transform.scale(bed_img, (30, 90))
    bed_img_rotated = pygame.transform.rotate(bed_img_scaled, 90)
    p1_paddle = pygame.Rect(20, HEIGHT//2 - 45, 90, 30)
    p2_paddle = pygame.Rect(WIDTH - 110, HEIGHT//2 - 45, 90, 30)
    mp_ball = pygame.Rect(WIDTH//2 - 15, HEIGHT//2 - 15, 30, 30)

speed_buttons = [
    (Button(60, 240, 110, 30, T('slow'), 14, (200,200,200)), 'slow'),
    (Button(195, 240, 110, 30, T('medium'), 14, (200,200,200)), 'medium'),
    (Button(330, 240, 110, 30, T('fast'), 14, (200,200,200)), 'fast'),
]
play_btn = Button(150, 285, 200, 40, T('play'), 24, (100, 255, 100))
mp_btn = Button(150, 335, 200, 35, T('mp'), 16, (255, 150, 100))
shop_btn = Button(150, 380, 200, 35, T('shop'), 16, (255, 200, 100))
settings_btn = Button(150, 425, 200, 30, T('settings'), 14, (200, 200, 200))
help_btn = Button(150, 465, 200, 25, T('help'), 12, (150, 150, 150))

music_btn = Button(10, 10, 150, 30, T('music_on'), 14, (100, 255, 100))
next_music_btn = Button(10, 50, 150, 30, T('next_track'), 12, (200, 200, 255))
lang_btn = Button(WIDTH - 60, 10, 50, 30, 'EN', 14, (200, 200, 255))

# --- ОБНОВЛЕНИЕ ТЕКСТОВ ПРИ СМЕНЕ ЯЗЫКА ---
def update_ui_language():
    global current_lang
    lang_btn.update_text('RU' if current_lang == 'en' else 'EN')
    
    back_shop_btn.update_text(T('back'))
    back_settings_btn.update_text(T('back'))
    back_help_btn.update_text(T('back'))
    
    fs_btn.update_text(T('fs_on') if is_fullscreen else T('fs_off'))
    admin_btn_add_score.update_text(T('admin_score'))
    admin_btn_add_lives.update_text(T('admin_lives'))
    admin_btn_kill_all.update_text(T('admin_kill'))
    admin_btn_god.update_text(T('admin_god_on') if god_mode else T('admin_god_off'))
    admin_btn_exit.update_text(T('close'))
    
    play_btn.update_text(T('play'))
    mp_btn.update_text(T('mp'))
    shop_btn.update_text(T('shop'))
    settings_btn.update_text(T('settings'))
    help_btn.update_text(T('help'))
    
    music_btn.update_text(T('music_on') if music_on else T('music_off'))
    next_music_btn.update_text(T('next_track'))
    
    for btn, key in speed_buttons:
        btn.update_text(T(key))

# --- ГЛАВНЫЙ ЦИКЛ ---
running = True
while running:
    mx, my = pygame.mouse.get_pos()
    mw.fill(back)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT: 
            running = False
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_F11:
                is_fullscreen = not is_fullscreen
                if is_fullscreen: mw = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN | pygame.SCALED)
                else: mw = pygame.display.set_mode((WIDTH, HEIGHT))
                update_ui_language()
            
            if event.key == pygame.K_TAB or event.key == pygame.K_F2:
                if game_state != 'admin':
                    prev_state = game_state
                    game_state = 'admin'
                else:
                    game_state = prev_state

            elif game_state == 'playing':
                if event.key == pygame.K_ESCAPE: game_state = 'paused'
                if event.key == pygame.K_b: prev_state = 'playing'; game_state = 'shop'
            
            elif game_state == 'multiplayer':
                if event.key == pygame.K_ESCAPE: game_state = 'menu'
            
            elif game_state == 'paused':
                if event.key == pygame.K_ESCAPE: game_state = 'playing'
                if event.key == pygame.K_m: 
                    game_state = 'menu'
                    if score > high_score: high_score = score
            
            elif game_state == 'gameover':
                if event.key == pygame.K_r: 
                    snd_game_over.stop(); snd_victory.stop()
                    reset_game(); pygame.mixer.music.unpause(); game_state = 'playing'
                if event.key == pygame.K_m: 
                    snd_game_over.stop(); snd_victory.stop()
                    pygame.mixer.music.unpause(); game_state = 'menu'
            
            elif game_state == 'glitch_victory':
                if event.key == pygame.K_r: 
                    snd_victory.stop(); reset_game(); pygame.mixer.music.unpause(); game_state = 'playing'
                if event.key == pygame.K_m: 
                    snd_victory.stop(); pygame.mixer.music.unpause(); game_state = 'menu'
            
            elif game_state == 'shop' or game_state == 'admin':
                if event.key == pygame.K_ESCAPE: game_state = prev_state
            
            elif game_state == 'help':
                if event.key == pygame.K_ESCAPE: game_state = 'menu'

        if event.type == MUSIC_END and music_on: 
            play_track(current_track_idx + 1)

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if game_state == 'menu':
                if lang_btn.rect.collidepoint(mx, my):
                    current_lang = 'en' if current_lang == 'ru' else 'ru'
                    update_ui_language()
                    snd_power.play()
                if music_btn.rect.collidepoint(mx, my):
                    music_on = not music_on
                    if music_on: pygame.mixer.music.unpause()
                    else: pygame.mixer.music.pause()
                    update_ui_language()
                if next_music_btn.rect.collidepoint(mx, my): play_track(current_track_idx + 1)
                for btn, key in speed_buttons:
                    if btn.rect.collidepoint(mx, my): current_speed_key = key
                if play_btn.rect.collidepoint(mx, my):
                    snd_game_over.stop(); snd_victory.stop()
                    reset_game(); pygame.mixer.music.unpause(); game_state = 'playing'
                if mp_btn.rect.collidepoint(mx, my):
                    init_multiplayer(); game_state = 'multiplayer'
                if shop_btn.rect.collidepoint(mx, my): prev_state = 'menu'; game_state = 'shop'
                if settings_btn.rect.collidepoint(mx, my): game_state = 'settings'
                if help_btn.rect.collidepoint(mx, my): game_state = 'help'
            
            elif game_state == 'settings':
                if fs_btn.rect.collidepoint(mx, my):
                    is_fullscreen = not is_fullscreen
                    if is_fullscreen: mw = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN | pygame.SCALED)
                    else: mw = pygame.display.set_mode((WIDTH, HEIGHT))
                    update_ui_language()
                if back_settings_btn.rect.collidepoint(mx, my): game_state = 'menu'
            
            elif game_state == 'help':
                if back_help_btn.rect.collidepoint(mx, my): game_state = 'menu'
            
            elif game_state == 'shop':
                if back_shop_btn.rect.collidepoint(mx, my):
                    game_state = prev_state
                for item in shop_items:
                    if item['rect'].collidepoint(mx, my) and score >= item['cost']:
                        if item['action'] == 'life' and lives < 5:
                            lives += 1; score -= item['cost']; snd_power.play()
                        elif item['action'] == 'width' and bed:
                            bed.rect.width = 160; bed.image = pygame.transform.scale(pygame.image.load(resource_path('bed.png')).convert_alpha(), (160, 30))
                            score -= item['cost']; snd_power.play()
                        elif item['action'] == 'slow':
                            dx = math.copysign(max(2, abs(dx) - 2), dx); dy = math.copysign(max(2, abs(dy) - 2), dy)
                            score -= item['cost']; snd_power.play()
                        elif item['action'] == 'speed':
                            platform_speed += 2; score -= item['cost']; snd_power.play()

            elif game_state == 'admin':
                if admin_btn_add_score.rect.collidepoint(mx, my): score += 1000; snd_power.play()
                if admin_btn_add_lives.rect.collidepoint(mx, my): lives += 5; snd_power.play()
                if admin_btn_kill_all.rect.collidepoint(mx, my): 
                    nagievs.clear(); snd_break.play()
                if admin_btn_god.rect.collidepoint(mx, my): 
                    god_mode = not god_mode
                    admin_btn_god.update_text(T('admin_god_on') if god_mode else T('admin_god_off'))
                    snd_power.play()
                if admin_btn_exit.rect.collidepoint(mx, my): 
                    game_state = prev_state

    keys = pygame.key.get_pressed()
    if keys[pygame.K_PLUS] or keys[pygame.K_EQUALS]:
        music_volume = min(1.0, music_volume + 0.01)
        pygame.mixer.music.set_volume(music_volume)
    if keys[pygame.K_MINUS]:
        music_volume = max(0.0, music_volume - 0.01)
        pygame.mixer.music.set_volume(music_volume)

    offset_x, offset_y = 0, 0
    if shake_timer > 0:
        shake_timer -= 1
        offset_x = random.randint(-shake_intensity, shake_intensity)
        offset_y = random.randint(-shake_intensity, shake_intensity)

    if game_state == 'menu':
        draw_text(mw, T('title'), 45, (255, 255, 0), WIDTH//2, 40)
        draw_text(mw, T('subtitle'), 16, (255, 255, 255), WIDTH//2, 70)
        draw_text(mw, T('goal'), 12, (255, 100, 100), WIDTH//2, 95)
        
        menu_bed_y = 130 + math.sin(pygame.time.get_ticks() / 200) * 5
        if bed: 
            try: mw.blit(pygame.transform.scale(pygame.image.load(resource_path('bed.png')).convert_alpha(), (100, 30)), (WIDTH//2 - 50, menu_bed_y))
            except: pass
        if verity: 
            try: mw.blit(pygame.transform.scale(pygame.image.load(resource_path('verity.png')).convert_alpha(), (40, 40)), (WIDTH//2 - 20, menu_bed_y - 40))
            except: pass

        draw_text(mw, T('record', high_score), 16, (255, 255, 0), WIDTH//2, 190)
        draw_text(mw, T('diff'), 14, (200, 200, 200), WIDTH//2, 220)

        music_btn.bg = (100, 255, 100) if music_on else (255, 100, 100)
        music_btn.draw(mw, hover=music_btn.rect.collidepoint((mx, my)))
        next_music_btn.draw(mw, hover=next_music_btn.rect.collidepoint((mx, my)))
        lang_btn.draw(mw, hover=lang_btn.rect.collidepoint((mx, my)))
        
        for btn, key in speed_buttons:
            btn.draw(mw, hover=btn.rect.collidepoint((mx, my)))
            if key == current_speed_key: pygame.draw.rect(mw, (255, 255, 0), btn.rect, 3, border_radius=8)
        
        play_btn.draw(mw, hover=play_btn.rect.collidepoint((mx, my)))
        mp_btn.draw(mw, hover=mp_btn.rect.collidepoint((mx, my)))
        shop_btn.draw(mw, hover=shop_btn.rect.collidepoint((mx, my)))
        settings_btn.draw(mw, hover=settings_btn.rect.collidepoint((mx, my)))
        help_btn.draw(mw, hover=help_btn.rect.collidepoint((mx, my)))
        draw_text(mw, 'TAB - Admin', 10, (100, 100, 100), WIDTH - 50, HEIGHT - 15)

    elif game_state == 'multiplayer':
        if keys[pygame.K_w] and p1_paddle.y > 0: p1_paddle.y -= 8
        if keys[pygame.K_s] and p1_paddle.y < HEIGHT - 30: p1_paddle.y += 8
        if keys[pygame.K_UP] and p2_paddle.y > 0: p2_paddle.y -= 8
        if keys[pygame.K_DOWN] and p2_paddle.y < HEIGHT - 30: p2_paddle.y += 8

        mp_ball.x += mp_dx; mp_ball.y += mp_dy

        if mp_ball.top <= 0: mp_ball.top = 0; mp_dy = abs(mp_dy); snd_bounce.play()
        elif mp_ball.bottom >= HEIGHT: mp_ball.bottom = HEIGHT; mp_dy = -abs(mp_dy); snd_bounce.play()

        if mp_ball.colliderect(p1_paddle) and mp_dx < 0:
            mp_ball.left = p1_paddle.right; mp_dx = abs(mp_dx)
            mp_dy = (mp_ball.centery - p1_paddle.centery) / 5; snd_bounce.play()
        if mp_ball.colliderect(p2_paddle) and mp_dx > 0:
            mp_ball.right = p2_paddle.left; mp_dx = -abs(mp_dx)
            mp_dy = (mp_ball.centery - p2_paddle.centery) / 5; snd_bounce.play()

        if mp_ball.left < 0:
            mp_p2_score += 1; snd_lose.play()
            mp_ball.center = (WIDTH//2, HEIGHT//2); mp_dx = 6; mp_dy = random.choice([-6, 6])
        elif mp_ball.right > WIDTH:
            mp_p1_score += 1; snd_win.play()
            mp_ball.center = (WIDTH//2, HEIGHT//2); mp_dx = -6; mp_dy = random.choice([-6, 6])

        if mp_p1_score >= 5 or mp_p2_score >= 5:
            winner = T('p1_win') if mp_p1_score >= 5 else T('p2_win')
            draw_text(mw, winner, 40, (50, 255, 50), WIDTH//2, HEIGHT//2 - 40)
            draw_text(mw, T('mp_esc'), 20, (200, 200, 200), WIDTH//2, HEIGHT//2 + 40)
        else:
            mw.blit(bed_img_rotated, (p1_paddle.x, p1_paddle.y))
            mw.blit(bed_img_rotated, (p2_paddle.x, p2_paddle.y))
            if verity:
                mw.blit(pygame.transform.scale(pygame.image.load(resource_path('verity.png')).convert_alpha(), (30, 30)), (mp_ball.x, mp_ball.y))
            draw_text(mw, f'{mp_p1_score} : {mp_p2_score}', 50, (255, 255, 255), WIDTH//2, 40)
            draw_text(mw, 'P1: W/S', 16, (100, 200, 255), 50, HEIGHT - 20)
            draw_text(mw, 'P2: UP/DOWN', 16, (255, 100, 100), WIDTH - 70, HEIGHT - 20)

    elif game_state == 'admin':
        draw_text(mw, T('admin_panel'), 40, (255, 0, 0), WIDTH//2, 50)
        admin_btn_add_score.draw(mw, hover=admin_btn_add_score.rect.collidepoint((mx, my)))
        admin_btn_add_lives.draw(mw, hover=admin_btn_add_lives.rect.collidepoint((mx, my)))
        admin_btn_kill_all.draw(mw, hover=admin_btn_kill_all.rect.collidepoint((mx, my)))
        admin_btn_god.bg = (100, 255, 100) if god_mode else (200, 200, 200)
        admin_btn_god.draw(mw, hover=admin_btn_god.rect.collidepoint((mx, my)))
        admin_btn_exit.draw(mw, hover=admin_btn_exit.rect.collidepoint((mx, my)))
        draw_text(mw, T('admin_hint'), 14, (150, 150, 150), WIDTH//2, 460)

    elif game_state == 'settings':
        draw_text(mw, T('settings'), 40, (255, 255, 0), WIDTH//2, 60)
        draw_text(mw, T('vol', int(music_volume*100)), 20, (255,255,255), WIDTH//2, 150)
        draw_text(mw, T('vol_hint'), 16, (200,200,200), WIDTH//2, 180)
        fs_btn.bg = (100, 255, 100) if is_fullscreen else (255, 100, 100)
        fs_btn.draw(mw, hover=fs_btn.rect.collidepoint((mx, my)))
        back_settings_btn.draw(mw, hover=back_settings_btn.rect.collidepoint((mx, my)))

    elif game_state == 'help':
        draw_text(mw, T('help'), 40, (255, 255, 0), WIDTH//2, 60)
        lines = T('help_text')
        for i, line in enumerate(lines):
            color = (255, 100, 255) if "куб" in line or "cube" in line else (200, 200, 200)
            if i < 2: color = (255, 255, 255)
            draw_text(mw, line, 14, color, WIDTH//2, 120 + i*25)
        back_help_btn.draw(mw, hover=back_help_btn.rect.collidepoint((mx, my)))

    elif game_state == 'shop':
        draw_text(mw, T('shop'), 40, (0, 255, 255), WIDTH//2, 60)
        draw_text(mw, T('points', score), 24, (255, 255, 255), WIDTH//2, 110)
        
        for i, item in enumerate(shop_items):
            rect = item['rect']
            can_buy = score >= item['cost']
            color = (100, 200, 100) if can_buy else (100, 50, 50)
            pygame.draw.rect(mw, color, rect, border_radius=5)
            pygame.draw.rect(mw, (255, 255, 255), rect, 2, border_radius=5)
            draw_text(mw, f"{T(item['key'])} - {item['cost']}", 16, (255, 255, 255), rect.centerx, rect.centery, False)

        back_shop_btn.draw(mw, hover=back_shop_btn.rect.collidepoint((mx, my)))
        draw_text(mw, T('shop_close'), 14, (150, 150, 150), WIDTH//2, 460)

    elif game_state == 'playing':
        if expand_timer > 0:
            expand_timer -= 1
            if expand_timer == 0:
                bed.rect.width = 100; bed.image = pygame.transform.scale(pygame.image.load(resource_path('bed.png')).convert_alpha(), (100, 30))
        if slow_timer > 0:
            slow_timer -= 1
            if slow_timer == 0:
                dx = math.copysign(base_dx, dx); dy = math.copysign(base_dy, dy)

        if keys[pygame.K_LEFT] and bed.rect.left > 0: bed.rect.x -= platform_speed
        if keys[pygame.K_RIGHT] and bed.rect.right < WIDTH: bed.rect.x += platform_speed

        verity_trail.append((verity.rect.centerx, verity.rect.centery))
        if len(verity_trail) > 8: verity_trail.pop(0)

        verity.rect.x += dx; verity.rect.y += dy

        if verity.rect.left <= 0:
            verity.rect.left = 0
            if dx < 0: dx = abs(dx); snd_bounce.play()
        elif verity.rect.right >= WIDTH:
            verity.rect.right = WIDTH
            if dx > 0: dx = -abs(dx); snd_bounce.play()
        if verity.rect.top <= 40:
            verity.rect.top = 40
            if dy < 0: dy = abs(dy); snd_bounce.play()

        if verity.rect.colliderect(bed.rect) and dy > 0: 
            verity.rect.bottom = bed.rect.top; dy = -abs(dy); snd_bounce.play()
            offset = (verity.rect.centerx - bed.rect.centerx) / (bed.rect.width / 2)
            dx = base_dx * offset
            if abs(dx) < 1: dx = 1 if dx > 0 else -1 

        if verity.rect.top > HEIGHT and not god_mode:
            lives -= 1; snd_lose.play(); shake_timer = 15; shake_intensity = 8
            if lives <= 0:
                game_result = 'lose'; game_state = 'gameover'
                if score > high_score: high_score = score
                pygame.mixer.music.pause(); snd_game_over.play()
            else:
                verity.rect.center = (WIDTH//2, HEIGHT//2); dx, dy = base_dx, base_dy; verity_trail.clear()
        elif verity.rect.top > HEIGHT and god_mode:
            verity.rect.bottom = HEIGHT; dy = -abs(dy)

        if glitch_cube:
            glitch_cube.update()
            if glitch_cube.rect.colliderect(bed.rect):
                snd_glitch.play(); is_secret_level = True; game_state = 'playing'
                create_level(); glitch_cube = None
            elif glitch_cube.rect.top > HEIGHT: glitch_cube = None

        hit_nagiev = next((m for m in nagievs if verity.rect.colliderect(m.rect)), None)
        if hit_nagiev:
            nagievs.remove(hit_nagiev); score += 10; snd_break.play()
            shake_timer = 8; shake_intensity = 5
            for _ in range(10): particles.append(Particle(hit_nagiev.rect.centerx, hit_nagiev.rect.centery, (255, 255, 0), True))
            if random.random() < 0.05 and not is_secret_level: glitch_cube = GlitchCube(hit_nagiev.rect.centerx, hit_nagiev.rect.centery)
            elif random.random() < 0.25: powerups.append(PowerUp(hit_nagiev.rect.centerx, hit_nagiev.rect.centery, random.choice(['expand', 'slow'])))
            dy = -dy 

        for p in powerups[:]:
            p.update()
            if p.rect.colliderect(bed.rect):
                powerups.remove(p); snd_power.play()
                if p.p_type == 'expand':
                    expand_timer = 300; bed.rect.width = 160; bed.image = pygame.transform.scale(pygame.image.load(resource_path('bed.png')).convert_alpha(), (160, 30))
                elif p.p_type == 'slow':
                    slow_timer = 300; dx = math.copysign(max(2, abs(dx) - 2), dx); dy = math.copysign(max(2, abs(dy) - 2), dy)
            elif p.rect.top > HEIGHT: powerups.remove(p)

        for pt in particles[:]:
            pt.update()
            if pt.life <= 0: particles.remove(pt)

        game_surface = pygame.Surface((WIDTH, HEIGHT))
        game_surface.fill(back)
        for i, pos in enumerate(verity_trail):
            alpha = int(255 * (i / len(verity_trail))); radius = int(15 * (i / len(verity_trail)))
            if radius > 0:
                s = pygame.Surface((radius*2, radius*2), pygame.SRCALPHA)
                pygame.draw.circle(s, (255, 255, 0, alpha), (radius, radius), radius)
                game_surface.blit(s, (pos[0] - radius, pos[1] - radius))

        bed.draw(game_surface); verity.draw(game_surface)
        for m in nagievs: m.draw(game_surface)
        for p in powerups: p.draw(game_surface)
        for pt in particles: pt.draw(game_surface)
        if glitch_cube: glitch_cube.draw(game_surface)
        mw.blit(game_surface, (offset_x, offset_y))

        draw_text(mw, T('score', score), 18, (255, 255, 255), 60, 20)
        lvl_text = T('secret') if is_secret_level else str(level)
        draw_text(mw, T('level', lvl_text), 18, (200, 200, 200), WIDTH//2, 20)
        draw_text(mw, T('lives', lives), 18, (255, 100, 100), WIDTH - 60, 20)
        if god_mode: draw_text(mw, 'GOD MODE', 14, (255, 255, 0), WIDTH//2, 45)

        if len(nagievs) == 0:
            if is_secret_level:
                game_result = 'glitch_win'; game_state = 'glitch_victory'
                pygame.mixer.music.pause(); snd_victory.play()
                if score > high_score: high_score = score
            elif level >= 3:
                game_result = 'win'; game_state = 'gameover'
                pygame.mixer.music.pause(); snd_victory.play()
                if score > high_score: high_score = score
            else:
                level += 1; snd_win.play(); create_level()

    elif game_state == 'paused':
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180)); mw.blit(overlay, (0, 0))
        draw_text(mw, T('paused'), 50, (255, 255, 255), WIDTH//2, HEIGHT//2 - 40)
        draw_text(mw, T('pause_esc'), 20, (200, 200, 200), WIDTH//2, HEIGHT//2 + 30)
        draw_text(mw, T('pause_m'), 20, (200, 200, 200), WIDTH//2, HEIGHT//2 + 70)

    elif game_state == 'glitch_victory':
        if random.random() < 0.5: mw.fill((random.randint(0, 50), random.randint(0, 50), random.randint(50, 100)))
        else: mw.fill((20, 20, 30))
        for i in range(5):
            ox, oy = random.randint(-10, 10), random.randint(-10, 10)
            draw_text(mw, T('glitch_win'), 45, random.choice([(255, 0, 255), (0, 255, 255), (255, 255, 0)]), WIDTH//2 + ox, HEIGHT//2 - 80 + oy, shadow=False)
        draw_text(mw, T('reality'), 30, (255, 255, 255), WIDTH//2, HEIGHT//2 - 20)
        draw_text(mw, T('your_score', score), 24, (200, 200, 200), WIDTH//2, HEIGHT//2 + 20)
        draw_text(mw, T('restart'), 20, (200, 200, 200), WIDTH//2, HEIGHT//2 + 100)
        draw_text(mw, T('menu'), 20, (200, 200, 200), WIDTH//2, HEIGHT//2 + 140)

    elif game_state == 'gameover':
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 200)); mw.blit(overlay, (0, 0))
        if game_result == 'lose': draw_text(mw, T('lose'), 40, (255, 50, 50), WIDTH//2, HEIGHT//2 - 80)
        else:
            draw_text(mw, T('win'), 45, (50, 255, 50), WIDTH//2, HEIGHT//2 - 80)
            draw_text(mw, T('win_sub'), 30, (255, 255, 255), WIDTH//2, HEIGHT//2 - 40)
        draw_text(mw, T('total', score), 24, (255, 255, 255), WIDTH//2, HEIGHT//2)
        if score >= high_score: draw_text(mw, T('new_rec'), 24, (255, 255, 0), WIDTH//2, HEIGHT//2 + 40)
        draw_text(mw, T('restart'), 20, (200, 200, 200), WIDTH//2, HEIGHT//2 + 100)
        draw_text(mw, T('menu'), 20, (200, 200, 200), WIDTH//2, HEIGHT//2 + 140)

    pygame.display.update()
    clock.tick(60)

pygame.quit()
sys.exit()